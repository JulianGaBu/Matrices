package Vista;

import javax.swing.*;

/**
 * Created by Julian on 21/11/2016.
 */
public class MainTextfield {
    private JTextArea mainTextArea;
    private JPanel panel1;
    private JTextArea userTextArea;
    private JButton notSureButton;
    private JButton sendButton;
}
