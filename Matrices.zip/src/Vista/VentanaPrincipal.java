package Vista;

import javax.swing.*;

/**
 * Created by Julian on 18/11/2016.
 */
public class VentanaPrincipal extends JFrame {

}
