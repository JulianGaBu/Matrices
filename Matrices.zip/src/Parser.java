/**
 * Created by Julian on 21/11/2016.
 */
public class Parser {
    String text = new String();

}
