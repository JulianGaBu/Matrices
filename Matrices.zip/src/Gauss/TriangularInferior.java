package Gauss;

import Listas.Cola;
import Listas.Stack;

import static java.util.stream.IntStream.range;

/**
 * Created by Julian on 21/11/2016.
 */
public class TriangularInferior {
    static Stack pilaInversas;
    static Cola colaInversas;
    private static void checkTuple(int numero, double valor){
        //esta funcion recibe dos valores que representan una eliminacion de matriz
        //donde el numero representa n en e_n
        //y donde el valor representa el escalar
        //se puede visualizar mejor con la siguiente matriz
        //  1  0  0  0 0
        // e1  1  0  0 0
        // e2 e3  1  0 0
        // e4 e5 e6  1 0
        // e7 e8 e9 e10 1
        // e11...........
        int i = 0;
        int j = 0;
        System.out.println(numero + "valor: " + valor);
        double[][] EMatrix = range(0, Factorizacion.nfilas).mapToObj(u -> range(0, Factorizacion.nfilas)
                .mapToDouble(v -> v == u ? 1 : 0).toArray())
                .toArray(double[][]::new);
        System.out.println(numero);
        //aqui checa el numero y le asigna su espacio correspondiente
        switch(numero){
            case 1: i = 1; j = 1; break;
            //fin de linea 2
            case 2:
            case 3: i = 2; j = numero-1-1; break;
            //fin de linea 3
            case 4:
            case 5:
            case 6: i = 3; j = numero-3-1; break;
            //fin de linea 4
            case 7:
            case 8:
            case 9:
            case 10:i = 4; j = numero-6-1; break;
            //fin de linea 5
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:i = 5; j = numero-10-1; break;
            //fin de linea 6
            case 16:
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:i = 6; j = numero-15-1; break;
        }

        System.out.println("COORDS----- X : "+i+" Y: "+j);

        //los guarda directamente con la inversa
        if(i==j)
            EMatrix[i][j] = 1/valor;
        else
            EMatrix[i][j] = -valor;

        Matrix.print(EMatrix);
        colaInversas.enqueue(EMatrix);
        pilaInversas.push(EMatrix);
    }

    public static void overloadProcessors(Stack pila){
        pilaInversas = new Stack();
        System.out.println("\n\n ----------"+pila.size());
        while(!pila.isEmpty()){
            int i = 0;
            System.out.println("\n--------"+i+" : "+(pila.size())+"-----\n");
            checkTuple((int) pila.pop(), (double) pila.pop());
        }
        //
        System.out.println("CLUSTER");
            Matrix.clusterMultiplication(colaInversas);


    }


}
