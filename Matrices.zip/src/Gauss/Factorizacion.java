package Gauss;

import Listas.Stack;

import java.util.ArrayList;

import static java.util.stream.IntStream.range;

/**
 * Created by Julian on 14/10/2016.
 */
public class Factorizacion {

    public static ArrayList<double[][]> pasos;
    public static Stack pila;
    static double determinante;
    public static int luNumber;
    public static int nfilas;
    public static int mcolumnas;
    //guarda los pasos de eliminacion en una pila con 2 valores, el numero de la matriz y su valor modificado.
    //Se usaran las inversas de estas matrices para generar L en [(LUx = Lc) = Ax = b]

    //TODO: IS FLOAT BETTER THAN DOUBLE???

    public static double[] vectorSolucion;
    //vector b en Ax = b. Escrito directo, en necesidad de interfaz

    /*public void vectorSol(ColaListaSimple vector){
        for(int i = 0; i < FILAS; i++){
            vectorSolucion[i] = (double)vector.dequeue();
        }
    }*/

    public static void eliminacion(double[][] matriz) {
        //se saca el tamaño de la matriz
        int FILAS = matriz.length;
        int COLUMNAS = matriz[0].length;
        nfilas = FILAS;
        mcolumnas = COLUMNAS;

        luNumber = 1;

        vectorSolucion = new double[FILAS];
        vectorSolucion[0] = 5.0;
        vectorSolucion[1] = -2.0;
        vectorSolucion[2] = 9.0;

        //se saca su identidad
        double[][] identidad = range(0, FILAS).mapToObj(j -> range(0, FILAS)
                .mapToDouble(i -> i == j ? 1 : 0).toArray())
                .toArray(double[][]::new);

        //se declaran o derivan las matrices del proceso
        double[][] P = permutar(matriz,identidad);
        double[][] A = matriz;
        double[][] L = new double[FILAS][FILAS];
        double[][] U = new double[FILAS][FILAS];
        matriz = Matrix.multiplication(P,matriz);

        //se notifica si se usa una matriz de permutacion
        if(P.equals(identidad)){
            System.out.println("La matriz se multiplica por la matriz de permutacion \n P = ");
            Matrix.print(P);
        }
        System.out.println("Ahora, sacamos la forma escalonada U");



        pasos = new ArrayList<>();
        pila = new Stack();
        //genera un nuevo arraylist con los pasos

        int pivote = 0; //Columna Actual que se manipula. n-1 espacios por cada iteracion




        int renglon; //renglón actual. Se usará para recorrera las filas de la matriz
        boolean alto = false; //Se usara para detener la eliminacion cuando este terminada




        for (int fila = 0; fila < FILAS && !alto; fila++) {
            //printSystem(matriz);
            System.out.println();

            //Si el pivote esta en la ultima columna (o mas alla), se detiene la eliminacion
            if (COLUMNAS <= pivote) {
                alto = true;
                break;
            }

            renglon = fila;
            //Si algun espacio es 0, se lo salta
            while (!alto && matriz[renglon][pivote] == 0) {
                renglon++;
                //Si llega al final y no encuenra un nuevo pivote
                if (FILAS == renglon) {
                    //reinicia las filas y mueve el pivote a la derecha
                    renglon = fila;
                    pivote++;

                    //detiene el ciclo si el pivote llega a la ultima columna
                    if (COLUMNAS == pivote) {
                        alto = true;
                        break;
                    }
                }
            }

            //Operaciones elementales de renglon
            if (!alto) {
                //Si algun espacio era 0, la matriz intercambia los renglones para poder escalonar
                //intercambia la fila_i con la fila_j
                if(fila != renglon)
                    intercambiarRenglones(matriz, renglon, fila);

                //resta Matriz[renglon,pivote] multiplicada por la fila() de la fila renglon
                //matriz, lambda, Rj, Ri
                //ri - lambda*rj
                for(renglon = fila+1; renglon < FILAS; renglon++) {
                    sumarRenglones(matriz, (matriz[renglon][pivote]/matriz[fila][pivote]), fila, renglon);
                }
            }
        }
        //imprime el sistema Ax = b resuelto
        Matrix.printSystem(matriz,vectorSolucion);

        //saca la determinante. Multiplica las diagonales
        determinante = 1;
        for(int i = 0; i < matriz.length; i++){
            for(int j = 0; j< matriz[0].length; j++){
                if(i == j){
                    determinante *= matriz[i][j];
                }
            }
        }
        System.out.println("Determinante = "+determinante);

        TriangularInferior.overloadProcessors(pila);


    }
    //intercambia ri con rj
    static void intercambiarRenglones(double[][] matriz, int Ri, int Rj) {
        //Arreglo temporal con los valores a cambiar
        double[] cambio = new double[matriz[0].length];
        for (int columna1 = 0; columna1 < matriz[0].length; columna1++)
            cambio[columna1] = matriz[Ri][columna1];

        //Intercambio de renglones (cambia cada elemento de cada columna individualmente
        for (int columna1 = 0; columna1 < matriz[0].length; columna1++) {
            matriz[Ri][columna1] = matriz[Rj][columna1];
            matriz[Rj][columna1] = cambio[columna1];

            System.out.println("Columna "+columna1+" - Renglon "+Ri+" -a- Renglon "+Rj);
        }

        //Intercambio de renglones en b
        //Todo: implementar el vector b correctamente
        Matrix.print(matriz);
        double aux = vectorSolucion[Ri];
        vectorSolucion[Ri] = vectorSolucion[Rj];
        vectorSolucion[Rj] = aux;
        //imprimir(matriz);
        Matrix.print(matriz);
        //System.out.println("lolklkkkkkkkkkkk");

    //MATRICES DE ELIMINACION
        //genera la matriz de eliminacion a partir de la identidad
        double[][] step = Sustitucion.generarIdentidad(matriz.length,matriz[0].length);
        for (int columna1 = 0; columna1 < step[0].length; columna1++) {
            double aux2 = step[Ri][columna1];
            step[Ri][columna1] = step[Rj][columna1];
            step[Rj][columna1] = aux2;

            System.out.println("STEP Columna "+columna1+" - Renglon "+Ri+" -a- Renglon "+Rj);
        }
        //...y la guarda en el arraylist
        //pasos.add(step);
        //pila.push(step);
    }

    //suma renglones multiplicados por escalares
    static void sumarRenglones(double[][] matriz, double escalar, int Rj, int Ri) {
        if(escalar < 0)
            System.out.println("R"+(Ri+1)+" + ("+(-escalar)+")R"+(Rj+1)+" -> R"+(Ri+1));
        else
            System.out.println("R"+(Ri+1)+" - ("+escalar+")R"+(Rj+1)+" -> R"+(Ri+1));
        for (int columna1 = 0; columna1 < matriz[0].length; columna1++)
            matriz[Ri][columna1] -= escalar * matriz[Rj][columna1];
        vectorSolucion[Ri] = vectorSolucion[Ri]-(escalar*vectorSolucion[Rj]);
        //imprimir(matriz);
        Matrix.print(matriz);
    //MATRICES DE ELIMINACION
        //genera la matriz de eliminacion a partir de la identidad
        double[][] step = Sustitucion.generarIdentidad(matriz.length,matriz[0].length);
        for (int columna1 = 0; columna1 < step[0].length; columna1++)
            step[Ri][columna1] -= escalar * step[Rj][columna1];
        pila.push(-escalar);
        pila.push(luNumber);
        luNumber++;
    }

    static public void imprimir(double[][] matriz) {
        int i = 0;
        for (int columna1 = 0; columna1 < matriz.length; columna1++) {
            System.out.print("[ ");

            for (int columna2 = 0; columna2 < matriz[0].length - 1; columna2++) {
                if(matriz[columna1][columna2+1] >= 0)
                    System.out.print(matriz[columna1][columna2] + ",\t ");
                else
                    System.out.print(matriz[columna1][columna2] + ",\t");
            }

            System.out.print(matriz[columna1][matriz[columna1].length - 1] + "\t]");
            if(vectorSolucion != null) {
                System.out.println("\t[" + vectorSolucion[i] + "\t]");
                i++;
            }else{
                System.out.println("");
            }
        }
    }

    //acomoda los pivotes para que esten en su valor mas alto
    static double[][] permutar(double[][] matriz, double[][] identidad) {
        int n = matriz.length;

        //va buscando el valor mayor de cada columna
        for (int i = 0; i < n; i++) {
            double maxm = matriz[i][i];
            int fila = i;
            for (int j = i; j < n; j++)
                if (matriz[j][i] > maxm) {
                    maxm = matriz[j][i];
                    fila = j;
                }
                //si encuentra uno mayor...
            //saca su matriz de permutacion desde la identidad
            if (i != fila) {
                double[] aux = identidad[i];
                identidad[i] = identidad[fila];
                identidad[fila] = aux;
            }
        }
        return identidad;
    }

    static double[][][] derivacionLower(double[][] A,double[][] P) {
        int n = A.length;
        double[][] L = new double[n][n];
        double[][] U = new double[n][n];
        double[][] A2 = Matrix.multiplication(P, A);

        for (int j = 0; j < n; j++) {
            L[j][j] = 1;
            for (int i = 0; i < j + 1; i++) {
                double s1 = 0;
                for (int k = 0; k < i; k++)
                    s1 += U[k][j] * L[i][k];
                U[i][j] = A2[i][j] - s1;
            }
            for (int i = j; i < n; i++) {
                double s2 = 0;
                for (int k = 0; k < j; k++)
                    s2 += U[k][j] * L[i][k];
                L[i][j] = (A2[i][j] - s2) / U[j][j];
            }
        }
        return new double[][][]{L, U, P};
    }
}
