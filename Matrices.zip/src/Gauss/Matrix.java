package Gauss;

import Listas.Stack;

import static java.util.Arrays.stream;
import static java.util.stream.IntStream.range;

/**
 * Created by Julian on 22/11/2016.
 */
public class Matrix {

    public static double dotProduct(double[] a, double[] b) {
        return range(0, a.length).mapToDouble(i -> a[i] * b[i]).sum();
    }

    public static double[][] multiplication(double[][] A, double[][] B) {
        double[][] result = new double[A.length][B[0].length];
        double[] aux = new double[B.length];

        for (int j = 0; j < B[0].length; j++) {

            for (int k = 0; k < B.length; k++)
                aux[k] = B[k][j];

            for (int i = 0; i < A.length; i++)
                result[i][j] = dotProduct(A[i], aux);
        }
        return result;
    }

    public static void clusterMultiplication(Stack pila){
        if(pila.size()>1){
            double[][] ultimo = (double[][])pila.pop();
            double[][] penultimo = (double[][])pila.pop();
            //pila.push(multiplication((double[][])pila.pop(),(double[][])pila.pop()));
            pila.push(multiplication(penultimo,ultimo));
            clusterMultiplication(pila);
        }
        else
            System.out.println("--------------H U H--------------");
            print((double[][])pila.pop());
    }

    public static void print(double[][] m) {
        System.out.print("[");
        stream(m).forEach(a -> {stream(a).forEach(n -> System.out.printf("%5.1f ", n));
            System.out.println("]");
            System.out.print("[");

        });
        System.out.println();
    }

    static public void printSystem(double[][] matriz, double[] vectorSolucion) {
        int i = 0;
        for (int columna1 = 0; columna1 < matriz.length; columna1++) {
            System.out.print("[ ");

            for (int columna2 = 0; columna2 < matriz[0].length - 1; columna2++) {
                if(matriz[columna1][columna2+1] >= 0)
                    System.out.print(matriz[columna1][columna2] + ",\t ");
                else
                    System.out.print(matriz[columna1][columna2] + ",\t");
            }

            System.out.print(matriz[columna1][matriz[columna1].length - 1] + "\t]");
            if(vectorSolucion != null) {
                System.out.println("\t[" + vectorSolucion[i] + "\t]");
                i++;
            }else{
                System.out.println("");
            }
        }
    }


}
